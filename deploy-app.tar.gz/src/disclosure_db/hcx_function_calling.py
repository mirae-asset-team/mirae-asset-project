"""Fail-closed HyperCLOVA X Function Calling over the existing Tool Registry.

The orchestration contract is transport-independent and can be tested with a
fake client.  The concrete client uses CLOVA Studio's documented
OpenAI-compatible Chat Completions surface; it does not own Tool schemas,
retrieval, evidence admission, or answerability policy.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
import json
import logging
import os
import re
from typing import Mapping, Protocol, Sequence
import urllib.error
import urllib.request
import uuid

from .generation import UNANSWERABLE_TEXT
from .calculator import calculate
from .evidence_sufficiency import EvidenceSufficiencyChecker
from .hcx_prompts import (
    HCX_FINAL_ANSWER_SYSTEM_PROMPT,
    HCX_FUNCTION_PROMPT_VERSION,
    HCX_ROUTED_FINAL_ANSWER_SYSTEM_PROMPT,
    HCX_TOOL_SELECTION_SYSTEM_PROMPT,
)
from .question_routing import QuestionRoute
from .tool_registry import ToolRegistry
from .tool_contracts import ToolEvidenceBundle


DEFAULT_HCX_BASE_URL = "https://clovastudio.stream.ntruss.com/v1/openai"
DEFAULT_HCX_MODEL = "HCX-005"
FUNCTION_CALLING_MAX_TOKENS = 1024
FINAL_ANSWER_TOOL_NAME = "submit_grounded_answer"
FUNCTION_FLOW_STATUSES = frozenset({"answered", "abstained", "invalid_request", "provider_unavailable", "error"})
_DART_RCEPT_NO = re.compile(r"\d{14}\Z")
_DART_RCEPT_NO_IN_TEXT = re.compile(r"접수번호\s*[:：]?\s*\d{14}")
_SAFE_DIAGNOSTIC_TOKEN = re.compile(r"[A-Za-z0-9_.:-]{1,128}\Z")
_LOGGER = logging.getLogger(__name__)


class HcxFunctionCallingError(RuntimeError):
    """Base error whose message is safe and contains no provider response."""

    def __init__(
        self,
        code: str,
        *,
        stage: str | None = None,
        http_status: int | None = None,
        provider_error_code: str | None = None,
    ) -> None:
        super().__init__(code)
        self.code = code if _SAFE_DIAGNOSTIC_TOKEN.fullmatch(code) else "hcx_error"
        self.stage = stage if stage and _SAFE_DIAGNOSTIC_TOKEN.fullmatch(stage) else None
        self.http_status = http_status
        self.provider_error_code = (
            provider_error_code
            if provider_error_code and _SAFE_DIAGNOSTIC_TOKEN.fullmatch(provider_error_code)
            else None
        )


class HcxNotConfiguredError(HcxFunctionCallingError):
    pass


class HcxProtocolError(HcxFunctionCallingError):
    pass


@dataclass(frozen=True, slots=True)
class HcxToolCall:
    call_id: str
    name: str
    arguments: Mapping[str, object]

    def __post_init__(self) -> None:
        if not self.call_id or len(self.call_id) > 256:
            raise ValueError("hcx_tool_call_id_invalid")
        if not self.name or len(self.name) > 100:
            raise ValueError("hcx_tool_name_invalid")
        if not isinstance(self.arguments, Mapping):
            raise ValueError("hcx_tool_arguments_not_object")
        object.__setattr__(self, "arguments", dict(self.arguments))

    def assistant_message(self) -> dict[str, object]:
        return {
            "role": "assistant",
            "content": "",
            "tool_calls": [{
                "id": self.call_id,
                "type": "function",
                "function": {
                    "name": self.name,
                    "arguments": json.dumps(self.arguments, ensure_ascii=False, separators=(",", ":")),
                },
            }],
        }


@dataclass(frozen=True, slots=True)
class HcxGeneratedAnswer:
    answer: str
    citation_ids: tuple[str, ...]

    def __post_init__(self) -> None:
        if not isinstance(self.answer, str) or not self.answer.strip() or len(self.answer) > 10_000:
            raise ValueError("hcx_final_answer_invalid")
        if not all(isinstance(item, str) and item for item in self.citation_ids):
            raise ValueError("hcx_final_citation_ids_invalid")


@dataclass(frozen=True, slots=True)
class HcxEvidenceCitation:
    evidence_id: str
    rcept_no: str
    report_name: str | None = None
    filed_at: str | None = None
    correction_role: str | None = None

    def __post_init__(self) -> None:
        if not self.evidence_id:
            raise ValueError("hcx_evidence_id_invalid")
        if _DART_RCEPT_NO.fullmatch(self.rcept_no) is None:
            raise ValueError("hcx_rcept_no_invalid")

    def to_dict(self) -> dict[str, object]:
        return {
            "evidence_id": self.evidence_id,
            "rcept_no": self.rcept_no,
            "report_name": self.report_name,
            "filed_at": self.filed_at,
            "correction_role": self.correction_role,
        }


class HcxFunctionClient(Protocol):
    model: str

    @property
    def configured(self) -> bool: ...

    def select_tool(
        self, question: str, tools: Sequence[Mapping[str, object]],
    ) -> HcxToolCall: ...

    def generate_answer(
        self, question: str, tool_call: HcxToolCall, tool_response: Mapping[str, object],
    ) -> HcxGeneratedAnswer: ...

    def generate_routed_answer(
        self, question: str, tool_call: HcxToolCall, tool_response: Mapping[str, object],
    ) -> HcxGeneratedAnswer: ...


class QuestionRouter(Protocol):
    def route(self, question: str) -> QuestionRoute | None: ...


@dataclass(slots=True)
class FunctionCallingResult:
    status: str
    answer: str
    tool_name: str | None = None
    tool_response: dict[str, object] | None = None
    answer_allowed: bool = False
    recommended_action: str = "abstain"
    citation_ids: list[str] = field(default_factory=list)
    citations: list[dict[str, object]] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    metadata: dict[str, object] = field(default_factory=dict)

    def to_dict(self) -> dict[str, object]:
        if self.status not in FUNCTION_FLOW_STATUSES:
            raise ValueError("function_calling_status_invalid")
        return {
            "status": self.status,
            "answer": self.answer,
            "tool_name": self.tool_name,
            "tool_response": self.tool_response,
            "answer_allowed": self.answer_allowed,
            "recommended_action": self.recommended_action,
            "citation_ids": list(dict.fromkeys(self.citation_ids)),
            "citations": [dict(item) for item in self.citations],
            "warnings": list(dict.fromkeys(self.warnings)),
            "metadata": dict(self.metadata),
        }


def hcx_tool_schemas(registry: ToolRegistry) -> list[dict[str, object]]:
    """Derive HCX/OpenAI tool definitions directly from Registry contracts."""

    tools: list[dict[str, object]] = []
    for contract in registry.list_tools():
        name = contract.get("name")
        description = contract.get("description")
        input_schema = contract.get("input_schema")
        if not isinstance(name, str) or not isinstance(description, str) or not isinstance(input_schema, Mapping):
            raise ValueError("tool_public_contract_invalid")
        tools.append({
            "type": "function",
            "function": {
                "name": name,
                "description": description,
                "parameters": input_schema,
            },
        })
    # JSON round-tripping both proves compatibility and prevents a provider or
    # caller from mutating the Registry's nested schema objects.
    return json.loads(json.dumps(tools, ensure_ascii=False))


def _final_answer_tool(evidence_ids: Sequence[str]) -> dict[str, object]:
    """Build the private HCX output contract from admitted Evidence IDs."""

    allowed_ids = list(dict.fromkeys(str(item) for item in evidence_ids if item))
    if not allowed_ids:
        raise HcxProtocolError(
            "hcx_final_evidence_ids_empty", stage="final_generation_preflight"
        )
    return {
        "type": "function",
        "function": {
            "name": FINAL_ANSWER_TOOL_NAME,
            "description": (
                "Tool Evidence만 사용한 최종 답변과 실제 사용한 evidence ID를 제출한다."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "answer": {
                        "type": "string",
                        "description": "DART Tool Evidence에만 근거한 한국어 최종 답변",
                    },
                    "citation_ids": {
                        "type": "array",
                        "description": "답변에 실제 사용한 evidence ID",
                        "items": {"type": "string", "enum": allowed_ids},
                        "minItems": 1,
                    },
                },
                "required": ["answer", "citation_ids"],
            },
        },
    }


def _argument_schema(value: object) -> dict[str, object]:
    if isinstance(value, bool):
        return {"type": "boolean"}
    if isinstance(value, int):
        return {"type": "integer"}
    if isinstance(value, float):
        return {"type": "number"}
    if isinstance(value, str):
        return {"type": "string"}
    if isinstance(value, Mapping):
        properties = {str(key): _argument_schema(item) for key, item in value.items()}
        return {
            "type": "object",
            "properties": properties,
            "required": list(properties),
        }
    if isinstance(value, (list, tuple)):
        item_schema = _argument_schema(value[0]) if value else {"type": "string"}
        return {"type": "array", "items": item_schema}
    return {"type": "string"}


def _conversation_tool(tool_call: HcxToolCall) -> dict[str, object]:
    """Echo the executed Tool definition so HCX accepts the follow-up turn."""

    properties = {
        str(name): _argument_schema(value)
        for name, value in tool_call.arguments.items()
    }
    return {
        "type": "function",
        "function": {
            "name": tool_call.name,
            "description": "The disclosure Tool already executed for this conversation.",
            "parameters": {
                "type": "object",
                "properties": properties,
                "required": list(properties),
            },
        },
    }


class HyperClovaFunctionClient:
    """Standard-library adapter for documented HCX OpenAI-compatible tools."""

    prompt_version = HCX_FUNCTION_PROMPT_VERSION

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        model: str | None = None,
        timeout: float = 20.0,
        env: Mapping[str, str] | None = None,
        urlopen: object | None = None,
    ) -> None:
        values = os.environ if env is None else env
        self.api_key = api_key if api_key is not None else values.get("CLOVASTUDIO_API_KEY") or None
        self.base_url = (
            base_url or values.get("CLOVASTUDIO_BASE_URL") or DEFAULT_HCX_BASE_URL
        ).rstrip("/")
        self.model = model or values.get("CLOVASTUDIO_MODEL") or DEFAULT_HCX_MODEL
        if timeout <= 0:
            raise ValueError("hcx_timeout_must_be_positive")
        self.timeout = float(timeout)
        self._urlopen = urlopen or urllib.request.urlopen

    @property
    def configured(self) -> bool:
        return bool(self.api_key)

    def select_tool(
        self, question: str, tools: Sequence[Mapping[str, object]],
    ) -> HcxToolCall:
        if not tools:
            raise HcxProtocolError("hcx_tools_empty", stage="tool_selection_preflight")
        data = self._chat({
            "model": self.model,
            "messages": [
                {
                    "role": "system",
                    "content": HCX_TOOL_SELECTION_SYSTEM_PROMPT,
                },
                {"role": "user", "content": question},
            ],
            "tools": list(tools),
            "tool_choice": "auto",
            "temperature": 0,
            "max_tokens": FUNCTION_CALLING_MAX_TOKENS,
        }, stage="tool_selection_request")
        message = self._message(data, stage="tool_selection_response")
        return self._tool_call(message, stage="tool_selection_response")

    @staticmethod
    def _tool_call(
        message: Mapping[str, object],
        *,
        stage: str,
        expected_name: str | None = None,
    ) -> HcxToolCall:
        raw_calls = message.get("tool_calls")
        if not isinstance(raw_calls, list) or len(raw_calls) != 1:
            raise HcxProtocolError("hcx_requires_exactly_one_tool_call", stage=stage)
        raw_call = raw_calls[0]
        if not isinstance(raw_call, Mapping) or raw_call.get("type") != "function":
            raise HcxProtocolError("hcx_tool_call_shape_invalid", stage=stage)
        function = raw_call.get("function")
        if not isinstance(function, Mapping):
            raise HcxProtocolError("hcx_tool_function_missing", stage=stage)
        name = str(function.get("name") or "")
        if expected_name is not None and name != expected_name:
            raise HcxProtocolError("hcx_unexpected_tool_call", stage=stage)
        arguments = function.get("arguments")
        if isinstance(arguments, str):
            try:
                arguments = json.loads(arguments)
            except json.JSONDecodeError as exc:
                raise HcxProtocolError("hcx_tool_arguments_invalid_json", stage=stage) from exc
        if not isinstance(arguments, Mapping):
            raise HcxProtocolError("hcx_tool_arguments_not_object", stage=stage)
        try:
            return HcxToolCall(
                str(raw_call.get("id") or ""), name, dict(arguments)
            )
        except ValueError as exc:
            raise HcxProtocolError(str(exc), stage=stage) from exc

    def generate_answer(
        self, question: str, tool_call: HcxToolCall, tool_response: Mapping[str, object],
    ) -> HcxGeneratedAnswer:
        bundle = tool_response.get("evidence_bundle")
        raw_evidence_ids = bundle.get("evidence_ids") if isinstance(bundle, Mapping) else None
        evidence_ids = (
            [str(item) for item in raw_evidence_ids if item]
            if isinstance(raw_evidence_ids, (list, tuple))
            else []
        )
        final_tool = _final_answer_tool(evidence_ids)
        tool_content = json.dumps(tool_response, ensure_ascii=False, separators=(",", ":"))
        data = self._chat({
            "model": self.model,
            "messages": [
                {
                    "role": "system",
                    "content": HCX_FINAL_ANSWER_SYSTEM_PROMPT,
                },
                {"role": "user", "content": question},
                tool_call.assistant_message(),
                {"role": "tool", "tool_call_id": tool_call.call_id, "content": tool_content},
            ],
            # CLOVA validates every assistant tool_call against the tools list
            # in the same stateless request.  Keep the already-executed Tool
            # alongside the private forced final-answer Tool.
            "tools": [_conversation_tool(tool_call), final_tool],
            "tool_choice": {
                "type": "function",
                "function": {"name": FINAL_ANSWER_TOOL_NAME},
            },
            "temperature": 0,
            "max_tokens": FUNCTION_CALLING_MAX_TOKENS,
        }, stage="final_generation_request")
        final_call = self._tool_call(
            self._message(data, stage="final_generation_response"),
            stage="final_generation_response",
            expected_name=FINAL_ANSWER_TOOL_NAME,
        )
        if set(final_call.arguments) != {"answer", "citation_ids"}:
            raise HcxProtocolError(
                "hcx_final_output_schema_mismatch", stage="final_generation_response"
            )
        answer = final_call.arguments.get("answer")
        citations = final_call.arguments.get("citation_ids")
        if not isinstance(answer, str) or not isinstance(citations, list) or not all(
            isinstance(item, str) for item in citations
        ):
            raise HcxProtocolError(
                "hcx_final_output_schema_mismatch", stage="final_generation_response"
            )
        try:
            return HcxGeneratedAnswer(answer, tuple(citations))
        except ValueError as exc:
            raise HcxProtocolError(str(exc), stage="final_generation_response") from exc

    def generate_routed_answer(
        self, question: str, tool_call: HcxToolCall, tool_response: Mapping[str, object],
    ) -> HcxGeneratedAnswer:
        """Generate once after a deterministic route without another Tool Call."""

        bundle = tool_response.get("evidence_bundle")
        raw_evidence_ids = bundle.get("evidence_ids") if isinstance(bundle, Mapping) else None
        evidence_ids = list(dict.fromkeys(
            str(item) for item in raw_evidence_ids if item
        )) if isinstance(raw_evidence_ids, (list, tuple)) else []
        if not evidence_ids:
            raise HcxProtocolError(
                "hcx_final_evidence_ids_empty", stage="final_generation_preflight"
            )
        data = self._chat({
            "model": self.model,
            "messages": [
                {
                    "role": "system",
                    "content": HCX_ROUTED_FINAL_ANSWER_SYSTEM_PROMPT,
                },
                {
                    "role": "user",
                    "content": json.dumps({
                        "question": question,
                        "tool_name": tool_call.name,
                        "tool_result": tool_response,
                    }, ensure_ascii=False, separators=(",", ":")),
                },
            ],
            "temperature": 0,
            "max_tokens": FUNCTION_CALLING_MAX_TOKENS,
        }, stage="routed_final_generation_request")
        message = self._message(data, stage="routed_final_generation_response")
        answer = message.get("content")
        if not isinstance(answer, str):
            raise HcxProtocolError(
                "hcx_final_answer_invalid", stage="routed_final_generation_response"
            )
        try:
            return HcxGeneratedAnswer(answer, tuple(evidence_ids[:5]))
        except ValueError as exc:
            raise HcxProtocolError(str(exc), stage="routed_final_generation_response") from exc

    def _chat(
        self, payload: Mapping[str, object], *, stage: str = "provider_request",
    ) -> Mapping[str, object]:
        if not self.api_key:
            raise HcxNotConfiguredError("hcx_api_key_not_configured", stage=stage)
        provider_request_id = str(uuid.uuid4())
        request = urllib.request.Request(
            f"{self.base_url}/chat/completions",
            data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
                "X-NCP-CLOVASTUDIO-REQUEST-ID": provider_request_id,
            },
            method="POST",
        )
        try:
            with self._urlopen(request, timeout=self.timeout) as response:  # type: ignore[operator]
                raw_response = response.read()
        except urllib.error.HTTPError as exc:
            raise HcxFunctionCallingError(
                "hcx_http_error",
                stage=stage,
                http_status=exc.code,
                provider_error_code=self._provider_error_code(exc),
            ) from exc
        except Exception as exc:
            raise HcxFunctionCallingError("hcx_request_failed", stage=stage) from exc
        try:
            data = json.loads(raw_response.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise HcxProtocolError("hcx_response_invalid_json", stage=stage) from exc
        if not isinstance(data, Mapping):
            raise HcxProtocolError("hcx_response_not_object", stage=stage)
        return data

    @staticmethod
    def _provider_error_code(error: urllib.error.HTTPError) -> str | None:
        """Extract only a bounded provider code; discard the raw error body."""

        try:
            raw = error.read(65_536)
            payload = json.loads(raw.decode("utf-8"))
        except Exception:
            return None
        provider_error = payload.get("error") if isinstance(payload, Mapping) else None
        code = provider_error.get("code") if isinstance(provider_error, Mapping) else None
        token = str(code) if code is not None else ""
        return token if _SAFE_DIAGNOSTIC_TOKEN.fullmatch(token) else None

    @staticmethod
    def _message(
        data: Mapping[str, object], *, stage: str = "provider_response",
    ) -> Mapping[str, object]:
        choices = data.get("choices")
        if not isinstance(choices, list) or len(choices) != 1 or not isinstance(choices[0], Mapping):
            raise HcxProtocolError("hcx_choices_shape_invalid", stage=stage)
        message = choices[0].get("message")
        if not isinstance(message, Mapping):
            raise HcxProtocolError("hcx_message_missing", stage=stage)
        return message


class HcxFunctionCallingService:
    """Select one Tool, dispatch it, enforce sufficiency, then optionally generate."""

    def __init__(
        self,
        registry: ToolRegistry,
        client: HcxFunctionClient,
        *,
        max_question_chars: int = 2_000,
        router: QuestionRouter | None = None,
    ) -> None:
        if max_question_chars <= 0:
            raise ValueError("max_question_chars_must_be_positive")
        self.registry = registry
        self.client = client
        self.max_question_chars = max_question_chars
        self.router = router
        self.evidence_checker = EvidenceSufficiencyChecker()

    def available_tools(self) -> list[dict[str, object]]:
        return hcx_tool_schemas(self.registry)

    @staticmethod
    def _fact_period_key(fact: Mapping[str, object]) -> str:
        period = fact.get("period")
        if not isinstance(period, Mapping):
            return ""
        return str(period.get("instant_date") or period.get("period_end") or period.get("period_start") or "")

    @staticmethod
    def _calculation_payload(result: object) -> dict[str, object]:
        return {
            "operation": str(getattr(result, "operation")),
            "value": str(getattr(result, "value")),
            "unit": getattr(result, "unit"),
            "evidence_ids": list(getattr(result, "evidence_ids")),
            "operands": [str(item) for item in getattr(result, "operands")],
        }

    @staticmethod
    def _bundle_from_response(response: Mapping[str, object]) -> Mapping[str, object]:
        bundle = response.get("evidence_bundle")
        return bundle if isinstance(bundle, Mapping) else {}

    def _merged_response(
        self,
        *,
        tool_name: str,
        request: Mapping[str, object],
        data: Mapping[str, object],
        responses: Sequence[Mapping[str, object]],
        checker_tool: str,
        checker_data: Mapping[str, object],
        required_response_indexes: Sequence[int] = (),
        extra_reasons: Sequence[str] = (),
        force_answer_allowed: bool | None = None,
    ) -> dict[str, object]:
        items: list[dict[str, object]] = []
        evidence_ids: list[str] = []
        filing_ids: list[str] = []
        issuer_codes: list[str] = []
        warnings: list[str] = []
        covered_scope: dict[str, object] = {}
        retrieval_status: dict[str, object] = {"route": "deterministic_multi_executor"}
        correction_statuses: list[str] = []
        for response in responses:
            bundle = self._bundle_from_response(response)
            raw_items = bundle.get("items")
            if isinstance(raw_items, list):
                items.extend(dict(item) for item in raw_items if isinstance(item, Mapping))
            for target, field_name in (
                (evidence_ids, "evidence_ids"),
                (filing_ids, "filing_ids"),
                (issuer_codes, "issuer_corp_codes"),
                (warnings, "quality_warnings"),
            ):
                values = bundle.get(field_name)
                if isinstance(values, (list, tuple)):
                    target.extend(str(item) for item in values if item)
            raw_covered = bundle.get("covered_scope")
            if isinstance(raw_covered, Mapping):
                for key, value in raw_covered.items():
                    if value not in (None, "", []):
                        covered_scope[str(key)] = value
            raw_retrieval = bundle.get("retrieval_status")
            if isinstance(raw_retrieval, Mapping):
                retrieval_status[str(response.get("tool_name") or len(retrieval_status))] = dict(raw_retrieval)
            correction_status = bundle.get("correction_status")
            if correction_status:
                correction_statuses.append(str(correction_status))
            raw_warnings = response.get("warnings")
            if isinstance(raw_warnings, list):
                warnings.extend(str(item) for item in raw_warnings if item)

        merged_bundle = ToolEvidenceBundle(
            question_intent=tool_name,
            requested_scope=dict(request),
            covered_scope=covered_scope,
            items=items,
            evidence_ids=evidence_ids,
            filing_ids=filing_ids,
            issuer_corp_codes=issuer_codes,
            quality_warnings=warnings,
            correction_status=(
                "resolved" if "resolved" in correction_statuses
                else correction_statuses[0] if correction_statuses
                else "not_evaluated"
            ),
            retrieval_status=retrieval_status,
        )
        checked = self.evidence_checker.check(checker_tool, request, merged_bundle, checker_data).to_dict()
        required_failed = any(
            index >= len(responses)
            or self._sufficiency(responses[index]).get("answer_allowed") is not True
            for index in required_response_indexes
        )
        if required_failed or force_answer_allowed is False:
            checked = {
                "status": "insufficient",
                "reasons": list(dict.fromkeys([*checked.get("reasons", []), *extra_reasons])),
                "missing_requirements": list(dict.fromkeys([
                    *checked.get("missing_requirements", []),
                    "required_executor_evidence",
                ])),
                "recommended_action": "abstain",
                "answer_allowed": False,
            }
        elif force_answer_allowed is True and checked.get("answer_allowed") is True:
            checked["reasons"] = list(dict.fromkeys([*checked.get("reasons", []), *extra_reasons]))
        merged_bundle.sufficiency = str(checked["status"])
        status = "success" if checked["status"] == "sufficient" else "partial" if checked["answer_allowed"] else "insufficient"
        return {
            "status": status,
            "tool_name": tool_name,
            "data": dict(data),
            "evidence_bundle": merged_bundle.to_dict(),
            "warnings": list(dict.fromkeys(warnings)),
            "metadata": {
                "schema_version": "tool-response-v1",
                "backend_version": "tool-registry-v1",
                "executors": [str(response.get("tool_name") or "unknown") for response in responses],
                "sufficiency_check": checked,
            },
        }

    def _financial_derived_response(
        self, route: QuestionRoute, primary: Mapping[str, object],
    ) -> dict[str, object]:
        data = primary.get("data")
        facts = data.get("facts") if isinstance(data, Mapping) else None
        ordered = sorted(
            (dict(item) for item in facts if isinstance(item, Mapping)),
            key=self._fact_period_key,
        ) if isinstance(facts, list) else []
        operation = str(route.context.get("operation") or "")
        calculations: list[dict[str, object]] = []
        try:
            if operation == "growth_rate":
                if len(ordered) < 2:
                    raise ValueError("growth_rate_requires_two_periods")
                for previous, current in zip(ordered, ordered[1:]):
                    ids = [
                        str(item)
                        for fact in (previous, current)
                        for item in fact.get("evidence_ids", [])
                        if item
                    ]
                    result = calculate(
                        operation,
                        [previous.get("value_numeric"), current.get("value_numeric")],
                        unit="%",
                        evidence_ids=ids,
                    )
                    calculations.append({
                        **self._calculation_payload(result),
                        "from_period": previous.get("period"),
                        "to_period": current.get("period"),
                    })
            elif operation in {"difference", "ratio"}:
                if len(ordered) < 2:
                    raise ValueError(f"{operation}_requires_two_periods")
                selected = ordered[-2:]
                result = calculate(
                    operation,
                    [item.get("value_numeric") for item in selected],
                    unit=selected[-1].get("unit") if operation == "difference" else None,
                    evidence_ids=[
                        str(evidence_id)
                        for item in selected
                        for evidence_id in item.get("evidence_ids", [])
                        if evidence_id
                    ],
                )
                calculations.append(self._calculation_payload(result))
            elif operation == "sum":
                if not ordered:
                    raise ValueError("sum_requires_facts")
                result = calculate(
                    operation,
                    [item.get("value_numeric") for item in ordered],
                    unit=ordered[-1].get("unit"),
                    evidence_ids=[
                        str(evidence_id)
                        for item in ordered
                        for evidence_id in item.get("evidence_ids", [])
                        if evidence_id
                    ],
                )
                calculations.append(self._calculation_payload(result))
            else:
                raise ValueError("derived_operation_unsupported")
        except (TypeError, ValueError):
            calculations = []
        return self._merged_response(
            tool_name="get_financial_facts",
            request=route.arguments,
            data={**dict(data or {}), "calculations": calculations},
            responses=[primary],
            checker_tool="get_financial_facts",
            checker_data=dict(data or {}),
            required_response_indexes=(0,),
            extra_reasons=("backend_calculation_complete",) if calculations else ("backend_calculation_unavailable",),
            force_answer_allowed=bool(calculations),
        )

    def _trend_response(
        self, question: str, route: QuestionRoute, primary: Mapping[str, object],
    ) -> dict[str, object]:
        summary_request = {
            "question": question,
            "correction_policy": "current",
            "top_k": 12,
            "max_chars": 8_000,
        }
        for name in ("company", "start_date", "end_date"):
            if route.arguments.get(name):
                summary_request[name] = route.arguments[name]
        content = self.registry.dispatch("build_summary_context", summary_request)
        primary_data = primary.get("data") if isinstance(primary.get("data"), Mapping) else {}
        return self._merged_response(
            tool_name="analyze_disclosure_trend",
            request=route.arguments,
            data={"quantitative_trend": dict(primary_data), "content_trend": dict(content.get("data") or {})},
            responses=[primary, content],
            checker_tool="analyze_disclosure_trend",
            checker_data=dict(primary_data),
            required_response_indexes=(0, 1),
            extra_reasons=("quantitative_and_content_evidence_merged",),
            force_answer_allowed=True,
        )

    def _change_reason_response(
        self, question: str, route: QuestionRoute, primary: Mapping[str, object],
    ) -> dict[str, object]:
        primary_data = primary.get("data") if isinstance(primary.get("data"), Mapping) else {}
        facts = primary_data.get("facts") if isinstance(primary_data, Mapping) else None
        ordered = sorted(
            (dict(item) for item in facts if isinstance(item, Mapping)),
            key=self._fact_period_key,
        ) if isinstance(facts, list) else []
        target_end = str(route.context.get("target_end_date") or "")
        if target_end:
            target_year = target_end[:4]
            indexes = [index for index, fact in enumerate(ordered) if self._fact_period_key(fact).startswith(target_year)]
            current_index = indexes[-1] if indexes else -1
        else:
            current_index = len(ordered) - 1
        calculations: list[dict[str, object]] = []
        if current_index <= 0:
            return self._merged_response(
                tool_name="get_financial_facts", request=route.arguments,
                data={**dict(primary_data), "calculations": [], "premise": "unverified"},
                responses=[primary], checker_tool="get_financial_facts", checker_data=dict(primary_data),
                required_response_indexes=(0,), extra_reasons=("comparison_period_missing",),
                force_answer_allowed=False,
            )
        previous, current = ordered[current_index - 1], ordered[current_index]
        evidence_ids = [
            str(item)
            for fact in (previous, current)
            for item in fact.get("evidence_ids", [])
            if item
        ]
        try:
            difference = calculate(
                "difference", [previous.get("value_numeric"), current.get("value_numeric")],
                unit=current.get("unit"), evidence_ids=evidence_ids,
            )
            growth = calculate(
                "growth_rate", [previous.get("value_numeric"), current.get("value_numeric")],
                unit="%", evidence_ids=evidence_ids,
            )
        except (TypeError, ValueError):
            return self._merged_response(
                tool_name="get_financial_facts", request=route.arguments,
                data={**dict(primary_data), "calculations": [], "premise": "unverified"},
                responses=[primary], checker_tool="get_financial_facts", checker_data=dict(primary_data),
                required_response_indexes=(0,), extra_reasons=("backend_calculation_unavailable",),
                force_answer_allowed=False,
            )
        calculations.extend((self._calculation_payload(difference), self._calculation_payload(growth)))
        increased = getattr(difference, "value") > 0
        base_data = {
            **dict(primary_data),
            "calculations": calculations,
            "premise": "confirmed_increase" if increased else "increase_not_confirmed",
        }
        if not increased:
            return self._merged_response(
                tool_name="get_financial_facts", request=route.arguments, data=base_data,
                responses=[primary], checker_tool="get_financial_facts", checker_data=dict(primary_data),
                required_response_indexes=(0,), extra_reasons=("question_premise_rejected_without_search",),
                force_answer_allowed=True,
            )
        search_request: dict[str, object] = {
            "question": question,
            "company": route.context.get("company"),
            "correction_policy": "current",
            "top_k": 10,
        }
        if route.context.get("target_start_date"):
            search_request["start_date"] = route.context["target_start_date"]
        if route.context.get("target_end_date"):
            search_request["end_date"] = route.context["target_end_date"]
        search = self.registry.dispatch("search_disclosures", search_request)
        return self._merged_response(
            tool_name="get_financial_facts", request=route.arguments,
            data={**base_data, "reason_evidence": dict(search.get("data") or {})},
            responses=[primary, search], checker_tool="get_financial_facts", checker_data=dict(primary_data),
            required_response_indexes=(0, 1), extra_reasons=("increase_verified_before_reason_search",),
            force_answer_allowed=True,
        )

    def _correction_response(
        self, route: QuestionRoute, search: Mapping[str, object],
    ) -> tuple[HcxToolCall, dict[str, object]]:
        bundle = self._bundle_from_response(search)
        items = bundle.get("items")
        rows = [item for item in items if isinstance(item, Mapping)] if isinstance(items, list) else []
        corrected = [item for item in rows if item.get("is_correction") is True]
        selected = corrected[0] if corrected else rows[0] if rows else None
        filing_id = str(selected.get("filing_id") or "") if selected is not None else ""
        if not filing_id:
            return HcxToolCall(f"call_{uuid.uuid4().hex[:24]}", "get_correction_lineage", {"filing_id": "00000000000000"}), self._merged_response(
                tool_name="get_correction_lineage", request=route.arguments,
                data={"search": dict(search.get("data") or {}), "original_filing": None, "corrected_filings": [], "current_filing": None, "lineage_confidence": "none"},
                responses=[search], checker_tool="get_correction_lineage", checker_data={},
                required_response_indexes=(0,), extra_reasons=("correction_receipt_not_found",),
                force_answer_allowed=False,
            )
        call = HcxToolCall(f"call_{uuid.uuid4().hex[:24]}", "get_correction_lineage", {"filing_id": filing_id})
        lineage = self.registry.dispatch(call.name, call.arguments)
        lineage_data = lineage.get("data") if isinstance(lineage.get("data"), Mapping) else {}
        return call, self._merged_response(
            tool_name="get_correction_lineage", request=call.arguments,
            data={**dict(lineage_data), "search": dict(search.get("data") or {})},
            responses=[search, lineage], checker_tool="get_correction_lineage", checker_data=dict(lineage_data),
            required_response_indexes=(1,), extra_reasons=("correction_search_and_lineage_merged",),
            force_answer_allowed=True,
        )

    def _document_summary_response(
        self, route: QuestionRoute, primary: Mapping[str, object],
    ) -> dict[str, object]:
        report_type = str(route.context.get("report_type") or "")
        bundle = self._bundle_from_response(primary)
        items = bundle.get("items")
        matched = [
            item for item in items
            if isinstance(item, Mapping) and report_type in str(item.get("report_name") or "")
        ] if isinstance(items, list) else []
        primary_data = primary.get("data") if isinstance(primary.get("data"), Mapping) else {}
        return self._merged_response(
            tool_name="build_summary_context",
            request=route.arguments,
            data={
                **dict(primary_data),
                "document_existence": "confirmed" if matched else "not_found",
                "requested_report_type": report_type,
            },
            responses=[primary],
            checker_tool="build_summary_context",
            checker_data=dict(primary_data),
            required_response_indexes=(0,),
            extra_reasons=("requested_document_confirmed",) if matched else ("requested_document_not_found",),
            force_answer_allowed=bool(matched),
        )

    def _execute_route(
        self, question: str, route: QuestionRoute, tool_call: HcxToolCall,
    ) -> tuple[HcxToolCall, dict[str, object]]:
        primary = self.registry.dispatch(tool_call.name, tool_call.arguments)
        if str(primary.get("status") or "error") in {"invalid_request", "error"}:
            return tool_call, primary
        if route.workflow == "financial_derived":
            return tool_call, self._financial_derived_response(route, primary)
        if route.workflow == "trend_with_content":
            return tool_call, self._trend_response(question, route, primary)
        if route.workflow == "financial_change_reason":
            return tool_call, self._change_reason_response(question, route, primary)
        if route.workflow == "correction_search_then_lineage":
            return self._correction_response(route, primary)
        if route.workflow == "document_summary_check":
            return tool_call, self._document_summary_response(route, primary)
        return tool_call, primary

    def answer(self, question: object) -> FunctionCallingResult:
        if not isinstance(question, str) or not question.strip() or len(question) > self.max_question_chars:
            return self._result(
                "invalid_request", "질문 형식이 올바르지 않습니다.", warnings=["question_invalid"]
            )
        question = question.strip()
        route = self.router.route(question) if self.router is not None else None
        if route is not None and route.kind in {"clarification", "unavailable"}:
            recommended_action = "ask_clarification" if route.kind == "clarification" else "abstain"
            bundle = ToolEvidenceBundle(
                question_intent=route.metric_kind.casefold(),
                requested_scope=dict(route.context),
                quality_warnings=[route.reason],
                correction_status="not_evaluated",
                sufficiency="insufficient",
            )
            tool_response = {
                "status": "insufficient",
                "tool_name": "resolver",
                "data": {
                    "ambiguity": dict(route.context) if route.kind == "clarification" else None,
                    "unavailable_reason": route.message if route.kind == "unavailable" else None,
                    "available_range": route.context.get("available_range"),
                },
                "evidence_bundle": bundle.to_dict(),
                "warnings": [route.reason],
                "metadata": {
                    "schema_version": "tool-response-v1",
                    "sufficiency_check": {
                        "status": "insufficient",
                        "reasons": [route.reason],
                        "missing_requirements": ["resolved_supported_question"],
                        "recommended_action": recommended_action,
                        "answer_allowed": False,
                    },
                },
            }
            return self._result(
                "abstained",
                route.message or "질문의 계정이나 범위를 더 구체적으로 알려주세요.",
                tool_response=tool_response,
                recommended_action=recommended_action,
                warnings=["deterministic_clarification" if route.kind == "clarification" else "deterministic_unavailable"],
                metadata={
                    "provider_configured": bool(self.client.configured),
                    "route_source": "deterministic",
                    "route_reason": route.reason,
                    "question_corrections": list(route.corrections),
                    "tool_selection_called": False,
                    "final_generation_called": False,
                },
            )

        tool_selection_called = route is None
        if not self.client.configured:
            return self._result(
                "provider_unavailable", UNANSWERABLE_TEXT,
                warnings=["hcx_api_key_not_configured"],
                metadata={
                    "provider_configured": False,
                    "route_source": "deterministic" if route is not None else "provider",
                    "route_reason": route.reason if route is not None else "provider_tool_selection",
                    "question_corrections": list(route.corrections) if route is not None else [],
                    "tool_selection_called": False,
                    "final_generation_called": False,
                },
            )
        if route is not None:
            tool_call = HcxToolCall(
                f"call_{uuid.uuid4().hex[:24]}",
                str(route.tool_name),
                route.arguments,
            )
        else:
            tools = self.available_tools()
            try:
                tool_call = self.client.select_tool(question, tools)
            except Exception as exc:
                diagnostics = self._record_failure("tool_selection", exc)
                return self._result(
                    "error", UNANSWERABLE_TEXT, warnings=["hcx_tool_selection_failed"],
                    metadata={"provider_configured": True, **diagnostics},
                )

        # Search/context Tools must execute the original user question.  A
        # malformed or omitted question still reaches Registry validation and
        # is rejected; only an already-string provider paraphrase is replaced.
        if isinstance(tool_call.arguments.get("question"), str):
            tool_call = HcxToolCall(
                tool_call.call_id,
                tool_call.name,
                {
                    **tool_call.arguments,
                    "question": (
                        route.normalized_question
                        if route is not None and route.normalized_question
                        else question
                    ),
                },
            )
        if route is not None:
            tool_call, tool_response = self._execute_route(question, route, tool_call)
        else:
            tool_response = self.registry.dispatch(tool_call.name, tool_call.arguments)
        tool_status = str(tool_response.get("status") or "error")
        sufficiency = self._sufficiency(tool_response)
        recommended_action = str(sufficiency.get("recommended_action") or "abstain")
        answer_allowed = (
            tool_status in {"success", "partial"}
            and sufficiency.get("answer_allowed") is True
            and recommended_action in {"answer", "answer_with_warning"}
        )
        common = {
            "tool_name": tool_call.name,
            "tool_response": tool_response,
            "recommended_action": recommended_action,
            "metadata": {
                "provider_configured": bool(self.client.configured),
                "model": self.client.model,
                "prompt_version": HCX_FUNCTION_PROMPT_VERSION,
                "route_source": "deterministic" if route is not None else "provider",
                "route_reason": route.reason if route is not None else "provider_tool_selection",
                "metric_kind": route.metric_kind if route is not None else "SEARCH",
                "workflow": route.workflow if route is not None else "function_calling_fallback",
                "question_corrections": list(route.corrections) if route is not None else [],
                "tool_selection_called": tool_selection_called,
                "final_generation_called": False,
            },
        }
        if tool_status == "invalid_request":
            return self._result(
                "invalid_request", self._abstention_text(recommended_action),
                warnings=["tool_request_rejected"], **common,
            )
        if tool_status == "error":
            return self._result(
                "error", self._abstention_text(recommended_action),
                warnings=["tool_execution_failed"], **common,
            )
        if not answer_allowed:
            return self._result(
                "abstained", self._abstention_text(recommended_action),
                warnings=["answer_generation_blocked_by_sufficiency"], **common,
            )

        available_citations = self._available_citations(tool_call.name, tool_response)
        common["metadata"]["available_citation_count"] = len(available_citations)  # type: ignore[index]
        common["metadata"]["valid_rcept_no_count"] = len({  # type: ignore[index]
            item.rcept_no for item in available_citations.values()
        })
        if not available_citations:
            common["recommended_action"] = "abstain"
            return self._result(
                "abstained", UNANSWERABLE_TEXT,
                warnings=["answer_generation_blocked_by_missing_rcept_no"], **common,
            )
        if (
            tool_call.name == "get_correction_lineage"
            and self._requires_correction_pair(tool_response)
            and not self._has_correction_pair(available_citations.values())
        ):
            common["recommended_action"] = "abstain"
            return self._result(
                "abstained", UNANSWERABLE_TEXT,
                warnings=["answer_generation_blocked_by_incomplete_correction_receipts"], **common,
            )

        common["metadata"]["final_generation_called"] = True  # type: ignore[index]
        failure_stage = "final_generation"
        try:
            generated = self.client.generate_routed_answer(question, tool_call, tool_response)
            failure_stage = "final_citation_validation"
            known_ids = {
                str(item) for item in (
                    tool_response.get("evidence_bundle", {}).get("evidence_ids", [])  # type: ignore[union-attr]
                ) if item
            }
            if not generated.citation_ids or any(item not in known_ids for item in generated.citation_ids):
                raise HcxProtocolError("hcx_final_citations_not_in_evidence_bundle")
            if _DART_RCEPT_NO_IN_TEXT.search(generated.answer):
                raise HcxProtocolError("hcx_final_answer_contains_provider_rendered_rcept_no")
            citations = self._selected_citations(
                tool_call.name, generated.citation_ids, available_citations
            )
            if not citations:
                raise HcxProtocolError("hcx_final_citations_missing_valid_rcept_no")
        except Exception as exc:
            common["metadata"].update(  # type: ignore[union-attr]
                self._record_failure(failure_stage, exc, tool_name=tool_call.name)
            )
            common["recommended_action"] = "abstain"
            return self._result(
                "error", UNANSWERABLE_TEXT, warnings=["hcx_final_generation_failed"], **common,
            )
        return self._result(
            "answered", self._render_answer(generated.answer, citations), answer_allowed=True,
            citation_ids=[item.evidence_id for item in citations],
            citations=[item.to_dict() for item in citations], **common,
        )

    @staticmethod
    def _deterministic_financial_answer(
        tool_response: Mapping[str, object],
        available_evidence_ids: Sequence[str],
    ) -> HcxGeneratedAnswer | None:
        data = tool_response.get("data")
        facts = data.get("facts") if isinstance(data, Mapping) else None
        if not isinstance(facts, list) or not facts or not available_evidence_ids:
            return None
        sentences: list[str] = []
        for raw_fact in facts[:5]:
            if not isinstance(raw_fact, Mapping) or raw_fact.get("value_numeric") is None:
                continue
            identifiers = raw_fact.get("company_identifiers")
            company = identifiers.get("company") if isinstance(identifiers, Mapping) else None
            account_name = raw_fact.get("account_name") or raw_fact.get("account_id") or "재무 수치"
            period = raw_fact.get("period")
            period_label = ""
            if isinstance(period, Mapping):
                instant = str(period.get("instant_date") or "")
                start = str(period.get("period_start") or "")
                end = str(period.get("period_end") or "")
                if instant:
                    period_label = instant
                elif start and end and start[:4] == end[:4]:
                    period_label = f"{end[:4]}년"
                elif start or end:
                    period_label = "~".join(item for item in (start, end) if item)
            scope = {"consolidated": "연결", "separate": "별도"}.get(str(raw_fact.get("scope") or ""), "")
            raw_value = str(raw_fact["value_numeric"])
            try:
                number = Decimal(raw_value)
                value = f"{number:,f}".rstrip("0").rstrip(".") if "." in f"{number:f}" else f"{number:,f}"
            except (InvalidOperation, ValueError):
                value = raw_value
            unit = "원" if str(raw_fact.get("unit") or "").upper() == "KRW" else str(raw_fact.get("unit") or "")
            scale = raw_fact.get("scale")
            scale_note = f"(원문 배율 {scale})" if scale not in (None, 1, "1") else ""
            subject = " ".join(str(item) for item in (company, period_label, scope, account_name) if item)
            sentences.append(f"{subject}은 {value}{unit}{scale_note}입니다.")
        if not sentences:
            return None
        answer = sentences[0] if len(sentences) == 1 else "\n".join(f"- {item}" for item in sentences)
        return HcxGeneratedAnswer(answer, tuple(available_evidence_ids[:5]))

    @staticmethod
    def _deterministic_trend_answer(
        tool_response: Mapping[str, object],
        available_evidence_ids: Sequence[str],
    ) -> HcxGeneratedAnswer | None:
        data = tool_response.get("data")
        if not isinstance(data, Mapping) or not available_evidence_ids:
            return None
        total_count = data.get("total_count")
        if not isinstance(total_count, int) or total_count <= 0:
            return None
        bundle = tool_response.get("evidence_bundle")
        requested_scope = bundle.get("requested_scope") if isinstance(bundle, Mapping) else None
        company = requested_scope.get("company") if isinstance(requested_scope, Mapping) else None
        requested_range = data.get("requested_range")
        start_date = requested_range.get("start_date") if isinstance(requested_range, Mapping) else None
        end_date = requested_range.get("end_date") if isinstance(requested_range, Mapping) else None

        period_rows = data.get("count_by_period")
        period_parts = [
            f"{row.get('period')} {row.get('count')}건"
            for row in period_rows
            if isinstance(row, Mapping) and row.get("period") and row.get("count") is not None
        ] if isinstance(period_rows, list) else []
        type_labels = {
            "periodic": "정기공시",
            "major": "주요사항공시",
            "exchange": "거래소공시",
            "holding": "지주회사공시",
        }
        type_rows = data.get("count_by_type")
        type_parts = [
            f"{type_labels.get(str(row.get('filing_type')), str(row.get('filing_type')))} {row.get('count')}건"
            for row in type_rows
            if isinstance(row, Mapping) and row.get("filing_type") and row.get("count") is not None
        ] if isinstance(type_rows, list) else []

        subject = str(company or "해당 회사")
        range_label = "~".join(str(item) for item in (start_date, end_date) if item)
        sentences = [f"{subject}의 {range_label or '요청 기간'} 공시는 총 {total_count}건입니다."]
        if period_parts:
            sentences.append("월별 건수는 " + ", ".join(period_parts) + "입니다.")
        if type_parts:
            sentences.append("유형별 건수는 " + ", ".join(type_parts) + "입니다.")
        if data.get("coverage_complete") is not True:
            sentences.append("요청 기간 전체가 아니라 현재 데이터에 수록된 공시 기준입니다.")
        return HcxGeneratedAnswer(" ".join(sentences), tuple(available_evidence_ids[:5]))

    @staticmethod
    def _available_citations(
        tool_name: str, tool_response: Mapping[str, object],
    ) -> dict[str, HcxEvidenceCitation]:
        bundle = tool_response.get("evidence_bundle")
        if not isinstance(bundle, Mapping):
            return {}
        items = bundle.get("items")
        if not isinstance(items, list):
            return {}
        role_by_rcept: dict[str, str] = {}
        data = tool_response.get("data")
        if tool_name == "get_correction_lineage" and isinstance(data, Mapping):
            original = data.get("original_filing")
            current = data.get("current_filing")
            corrected = data.get("corrected_filings")
            if isinstance(original, Mapping) and original.get("filing_id"):
                role_by_rcept[str(original["filing_id"])] = "최초공시"
            if isinstance(corrected, list):
                for row in corrected:
                    if isinstance(row, Mapping) and row.get("filing_id"):
                        role_by_rcept[str(row["filing_id"])] = "정정공시"
            if isinstance(current, Mapping) and current.get("filing_id"):
                current_id = str(current["filing_id"])
                role_by_rcept.setdefault(current_id, "현재공시")
        citations: dict[str, HcxEvidenceCitation] = {}
        for raw_item in items:
            if not isinstance(raw_item, Mapping):
                continue
            rcept_no = str(raw_item.get("rcept_no") or raw_item.get("filing_id") or "")
            if _DART_RCEPT_NO.fullmatch(rcept_no) is None:
                continue
            raw_ids = raw_item.get("evidence_ids")
            evidence_ids = list(raw_ids) if isinstance(raw_ids, (list, tuple)) else []
            if raw_item.get("evidence_id"):
                evidence_ids.insert(0, raw_item["evidence_id"])
            for evidence_id in dict.fromkeys(str(item) for item in evidence_ids if item):
                citations[evidence_id] = HcxEvidenceCitation(
                    evidence_id=evidence_id,
                    rcept_no=rcept_no,
                    report_name=str(raw_item.get("report_name") or "DART 공시"),
                    filed_at=str(raw_item["filed_at"]) if raw_item.get("filed_at") else None,
                    correction_role=role_by_rcept.get(rcept_no),
                )
        return citations

    @staticmethod
    def _has_correction_pair(citations: Sequence[HcxEvidenceCitation]) -> bool:
        roles = {item.correction_role for item in citations}
        return "최초공시" in roles and "정정공시" in roles

    @staticmethod
    def _requires_correction_pair(tool_response: Mapping[str, object]) -> bool:
        data = tool_response.get("data")
        corrected = data.get("corrected_filings") if isinstance(data, Mapping) else None
        return isinstance(corrected, list) and bool(corrected)

    @staticmethod
    def _selected_citations(
        tool_name: str,
        generated_ids: Sequence[str],
        available: Mapping[str, HcxEvidenceCitation],
    ) -> list[HcxEvidenceCitation]:
        identifiers = list(available) if tool_name == "get_correction_lineage" else list(generated_ids)
        selected: list[HcxEvidenceCitation] = []
        seen_receipts: set[str] = set()
        for evidence_id in identifiers:
            citation = available.get(evidence_id)
            if citation is None or citation.rcept_no in seen_receipts:
                continue
            seen_receipts.add(citation.rcept_no)
            selected.append(citation)
        return selected

    @staticmethod
    def _render_answer(answer: str, citations: Sequence[HcxEvidenceCitation]) -> str:
        lines = [answer.strip(), "", "근거 공시"]
        if len(citations) == 1:
            citation = citations[0]
            label = " ".join(item for item in (citation.correction_role, citation.report_name) if item)
            lines.extend([f"- {label or 'DART 공시'}", f"- 접수번호: {citation.rcept_no}"])
        else:
            for index, citation in enumerate(citations, start=1):
                label = " ".join(item for item in (citation.correction_role, citation.report_name) if item)
                lines.append(f"{index}. {label or 'DART 공시'} — 접수번호: {citation.rcept_no}")
        return "\n".join(lines)

    @staticmethod
    def _sufficiency(tool_response: Mapping[str, object]) -> Mapping[str, object]:
        metadata = tool_response.get("metadata")
        if not isinstance(metadata, Mapping):
            return {}
        sufficiency = metadata.get("sufficiency_check")
        return sufficiency if isinstance(sufficiency, Mapping) else {}

    @staticmethod
    def _abstention_text(action: str) -> str:
        if action == "ask_clarification":
            return "근거 범위를 확정할 수 있도록 회사, 계정 또는 기간을 더 구체적으로 알려주세요."
        return UNANSWERABLE_TEXT

    def _record_failure(
        self,
        fallback_stage: str,
        error: Exception,
        *,
        tool_name: str | None = None,
    ) -> dict[str, object]:
        """Log content-free diagnostics and return the same safe trace fields."""

        stage = fallback_stage
        error_code = "hcx_unexpected_error"
        http_status: int | None = None
        provider_error_code: str | None = None
        if isinstance(error, HcxFunctionCallingError):
            stage = error.stage or fallback_stage
            error_code = error.code
            http_status = error.http_status
            provider_error_code = error.provider_error_code
        elif _SAFE_DIAGNOSTIC_TOKEN.fullmatch(str(error)):
            error_code = str(error)
        diagnostics: dict[str, object] = {
            "error_stage": stage,
            "error_type": type(error).__name__,
            "error_code": error_code,
        }
        if http_status is not None:
            diagnostics["http_status"] = http_status
        if provider_error_code is not None:
            diagnostics["provider_error_code"] = provider_error_code
        event = {
            "event": "hcx_function_calling_failure",
            "prompt_version": HCX_FUNCTION_PROMPT_VERSION,
            **diagnostics,
        }
        if tool_name and _SAFE_DIAGNOSTIC_TOKEN.fullmatch(tool_name):
            event["tool_name"] = tool_name
        _LOGGER.warning(
            "hcx_function_calling_failure %s",
            json.dumps(event, ensure_ascii=True, sort_keys=True, separators=(",", ":")),
        )
        return diagnostics

    def _result(
        self,
        status: str,
        answer: str,
        *,
        tool_name: str | None = None,
        tool_response: dict[str, object] | None = None,
        answer_allowed: bool = False,
        recommended_action: str = "abstain",
        citation_ids: list[str] | None = None,
        citations: list[dict[str, object]] | None = None,
        warnings: list[str] | None = None,
        metadata: dict[str, object] | None = None,
    ) -> FunctionCallingResult:
        return FunctionCallingResult(
            status=status,
            answer=answer,
            tool_name=tool_name,
            tool_response=tool_response,
            answer_allowed=answer_allowed,
            recommended_action=recommended_action,
            citation_ids=list(citation_ids or []),
            citations=[dict(item) for item in (citations or [])],
            warnings=list(warnings or []),
            metadata={
                "model": getattr(self.client, "model", None),
                "prompt_version": HCX_FUNCTION_PROMPT_VERSION,
                **dict(metadata or {}),
            },
        )


__all__ = [
    "DEFAULT_HCX_BASE_URL",
    "DEFAULT_HCX_MODEL",
    "FINAL_ANSWER_TOOL_NAME",
    "FUNCTION_CALLING_MAX_TOKENS",
    "FunctionCallingResult",
    "HcxFunctionCallingError",
    "HcxFunctionCallingService",
    "HcxEvidenceCitation",
    "HcxGeneratedAnswer",
    "HcxNotConfiguredError",
    "HcxProtocolError",
    "HcxToolCall",
    "HyperClovaFunctionClient",
    "hcx_tool_schemas",
]
